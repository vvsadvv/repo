--
-- PostgreSQL database dump
--

\restrict B9VVQ8BuvyBMBMvDWiWCnA96r2RJflZMIFDsx7ThoScnHa6OtXIkSkFhSvdoIlw

-- Dumped from database version 13.23
-- Dumped by pg_dump version 13.23

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: repository_personal_drafts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repository_personal_drafts (
    user_id text NOT NULL,
    document_id text NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    blocks jsonb DEFAULT '[]'::jsonb NOT NULL,
    source_updated_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    document_status character varying(32) DEFAULT 'draft'::character varying NOT NULL,
    review_requested_at timestamp without time zone,
    verified_at timestamp without time zone,
    CONSTRAINT repository_personal_drafts_document_status_check CHECK (((document_status)::text = ANY ((ARRAY['draft'::character varying, 'needs_revision'::character varying, 'under_review'::character varying, 'verified'::character varying])::text[])))
);


--
-- Name: repositoryauthororganizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repositoryauthororganizations (
    id integer NOT NULL,
    author_id integer NOT NULL,
    organization_id integer NOT NULL,
    status character varying(20) DEFAULT 'approved'::character varying NOT NULL,
    requested_by_user_id integer,
    approved_by integer,
    approved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT repository_author_organizations_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying])::text[])))
);


--
-- Name: repositoryauthororganizations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.repositoryauthororganizations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: repositoryauthororganizations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.repositoryauthororganizations_id_seq OWNED BY public.repositoryauthororganizations.id;


--
-- Name: repositoryauthors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repositoryauthors (
    id integer NOT NULL,
    name_ru character varying(255) NOT NULL,
    name_en character varying(255) NOT NULL,
    status character varying(20) DEFAULT 'approved'::character varying NOT NULL,
    requested_by_user_id integer,
    requester_name character varying(255),
    requester_email character varying(255),
    approved_by integer,
    approved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT repository_authors_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying])::text[])))
);


--
-- Name: repositoryauthors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.repositoryauthors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: repositoryauthors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.repositoryauthors_id_seq OWNED BY public.repositoryauthors.id;


--
-- Name: repositoryorganizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repositoryorganizations (
    id integer NOT NULL,
    name_ru character varying(255) NOT NULL,
    name_en character varying(255),
    status character varying(20) DEFAULT 'approved'::character varying NOT NULL,
    requested_by_user_id integer,
    requester_name character varying(255),
    requester_email character varying(255),
    approved_by integer,
    approved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    full_name_ru text,
    full_name_en text,
    CONSTRAINT repository_organizations_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying])::text[])))
);


--
-- Name: repositoryorganizations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.repositoryorganizations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: repositoryorganizations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.repositoryorganizations_id_seq OWNED BY public.repositoryorganizations.id;


--
-- Name: repositorypasswordresettokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repositorypasswordresettokens (
    id integer NOT NULL,
    repository_user_id integer NOT NULL,
    token character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    used boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: repositorypasswordresettokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.repositorypasswordresettokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: repositorypasswordresettokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.repositorypasswordresettokens_id_seq OWNED BY public.repositorypasswordresettokens.id;


--
-- Name: repositoryuserprofileupdaterequests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repositoryuserprofileupdaterequests (
    id integer NOT NULL,
    repository_user_id integer NOT NULL,
    requested_changes jsonb DEFAULT '{}'::jsonb NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    admin_comment text,
    reviewed_by integer,
    reviewed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT repository_user_profile_update_requests_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying])::text[])))
);


--
-- Name: repositoryuserprofileupdaterequests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.repositoryuserprofileupdaterequests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: repositoryuserprofileupdaterequests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.repositoryuserprofileupdaterequests_id_seq OWNED BY public.repositoryuserprofileupdaterequests.id;


--
-- Name: repositoryusers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repositoryusers (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    full_name character varying(255),
    email character varying(255) NOT NULL,
    organization character varying(255),
    "position" character varying(255),
    password character varying(255) NOT NULL,
    password_changed_at timestamp without time zone,
    role character varying(20) DEFAULT 'user'::character varying NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    approved_by integer,
    approved_at timestamp without time zone,
    organization_id integer,
    personal_data_consent boolean DEFAULT false NOT NULL,
    personal_data_consent_at timestamp without time zone,
    CONSTRAINT repository_users_role_check CHECK (((role)::text = ANY ((ARRAY['admin'::character varying, 'editor'::character varying, 'user'::character varying])::text[]))),
    CONSTRAINT repository_users_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'active'::character varying, 'blocked'::character varying])::text[])))
);


--
-- Name: repositoryusers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.repositoryusers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: repositoryusers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.repositoryusers_id_seq OWNED BY public.repositoryusers.id;


--
-- Name: repositoryauthororganizations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositoryauthororganizations ALTER COLUMN id SET DEFAULT nextval('public.repositoryauthororganizations_id_seq'::regclass);


--
-- Name: repositoryauthors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositoryauthors ALTER COLUMN id SET DEFAULT nextval('public.repositoryauthors_id_seq'::regclass);


--
-- Name: repositoryorganizations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositoryorganizations ALTER COLUMN id SET DEFAULT nextval('public.repositoryorganizations_id_seq'::regclass);


--
-- Name: repositorypasswordresettokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositorypasswordresettokens ALTER COLUMN id SET DEFAULT nextval('public.repositorypasswordresettokens_id_seq'::regclass);


--
-- Name: repositoryuserprofileupdaterequests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositoryuserprofileupdaterequests ALTER COLUMN id SET DEFAULT nextval('public.repositoryuserprofileupdaterequests_id_seq'::regclass);


--
-- Name: repositoryusers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositoryusers ALTER COLUMN id SET DEFAULT nextval('public.repositoryusers_id_seq'::regclass);


--
-- Data for Name: repository_personal_drafts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repository_personal_drafts (user_id, document_id, name, meta, blocks, source_updated_at, created_at, updated_at, document_status, review_requested_at, verified_at) FROM stdin;
7	78dd79ed-3ca5-4ed4-a697-c448e0566abc	новое название	{"doi": "", "volume": "", "authors": "Габсатарова Ирина Петровна", "license": "CC BY NC 4.0", "titleEn": "new name ", "xmlPath": "", "position": 0, "authorsEn": "Gabsatarova Irina Petrovna", "annotation": "Региональный каталог сейсмических событий включает в себя данные о параметрах гипоцентров, коды сейсмологических центров (сетей), названия географического района, а также макросейсмические сведения. В качестве основной энергетической оценки принята расчетная магнитуда M (Кр, MPVA рег), полученная по соотношениям с инструментально определенными магнитудами и классами. \\nКаталог сейсмических событий составлен из региональных каталогов различных обрабатывающих центров и содержит сведения о 2304 событиях (землетрясения, взрывы, \\"\\"возможно взрыв\\"\\" и известный химический взрыв), из них 2256 землетрясений и 48 взрывов. \\nРегиональный каталог сейсмических событий Северного Кавказа является источником информации о сейсмических событиях за 2024 г. для базы данных «Землетрясения России», которой открыт публичный доступ с сайта «Землетрясения России» (http://www.gsras.ru/zr/).", "recordType": "dataset", "creatorName": "Сдельникова Ирина Александровна", "journalCode": "er", "affiliations": "GS RAS", "bibliography": "", "citationLink": "Габсатарова И.П. новое название [Электронный ресурс] // Репозиторий геофизических данных. – Обнинск: ФИЦ ЕГС РАН, 2026.", "creatorEmail": "newsbox@gsras.ru", "documentType": "dataset", "organization": "ФИЦ ЕГС РАН", "articleNumber": "", "authorEntries": [{"id": "author-1780473538032-eda0e7904d1eb", "authorEn": "Gabsatarova Irina Petrovna", "authorRu": "Габсатарова Ирина Петровна", "organizationEn": "GS RAS", "organizationRu": "ФИЦ ЕГС РАН", "referenceAuthorId": 5, "organizationFullEn": "Geophysical survey of the Russian academy of sciences", "organizationFullRu": "Федеральное государственное бюджетное учреждение науки Федеральный исследовательский центр \\"Единая геофизическая служба Российской академии наук\\"", "referenceOrganizationId": 1}], "creatorUserId": "7", "descriptionEn": "The regional seismic event catalog includes data on hypocenter parameters, seismological center (network) codes, geographic area names, and macroseismic data. The primary energy estimate is the estimated magnitude M (KR, MPVA reg), obtained by correlation with instrumentally determined magnitudes and classes.\\nThe seismic event catalog is compiled from regional catalogs of various processing centers and contains information on 2304 events (earthquakes, explosions, \\"\\"possible explosions,\\"\\" and known chemical explosions), including 2256 earthquakes and 48 explosions.\\nThe regional seismic event catalog for the North Caucasus is the source of information on seismic events for 2024 for the \\"\\"Earthquakes of Russia\\"\\" database, which is publicly accessible from the \\"\\"Earthquakes of Russia\\"\\" website (http://www.gsras.ru/zr/).", "citationLinkEn": "Gabsatarova I.P. (2026). new name. Geophysical Data Repository, Geophysical Survey of the Russian Academy of Sciences, Obninsk,", "organizationEn": "GS RAS", "publicationDate": "2026-06-03", "revisionComment": "", "reviewEditorName": "", "reviewEditorEmail": "", "revisionCommentAuthor": "", "revisionCommentUpdatedAt": ""}	[]	2026-06-18 09:07:21.381	2026-06-03 11:00:17.79597	2026-06-18 12:07:57.32949	draft	\N	\N
5	1a9ebee6-6adb-4c0a-bd6e-244fe0606695	Опять тест	{"doi": "", "volume": "1", "authors": "", "license": "CC BY NC 4.0", "titleEn": "Test one more", "xmlPath": "", "position": 0, "authorsEn": "", "annotation": "", "recordType": "dataset", "creatorName": "Сдельникова Ирина Александровна", "journalCode": "", "affiliations": "", "bibliography": "", "citationLink": "Опять тест [Электронный ресурс] // Репозиторий геофизических данных. – Обнинск: ФИЦ ЕГС РАН, 2026.", "creatorEmail": "us@gsras.ru", "documentType": "dataset", "organization": "ФИЦ ЕГС РАН", "articleNumber": "23", "authorEntries": [{"id": "author-1782461833521-9768ea9fdd6278", "authorEn": "", "authorRu": "", "organizationEn": "", "organizationRu": "", "referenceAuthorId": null, "organizationFullEn": "", "organizationFullRu": "", "referenceOrganizationId": null}], "creatorUserId": "5", "descriptionEn": "", "citationLinkEn": "(2026). Test one more. Geophysical Data Repository, Geophysical Survey of the Russian Academy of Sciences, Obninsk,", "organizationEn": "", "publicationDate": "2026-06-26", "revisionComment": "", "reviewEditorName": "", "reviewEditorEmail": "", "revisionCommentAuthor": "", "revisionCommentUpdatedAt": ""}	[]	2026-06-26 08:27:51.753	2026-06-26 11:18:37.960679	2026-06-26 11:37:19.153491	draft	\N	\N
4	7a71692f-1fad-47ef-b324-d4b846e864a7	Каталог землетрясений Крымско-Черноморского региона за 2024 год	{"doi": "10.35540/gsras.upp.2026.1.01", "volume": "1", "authors": "Бондарь Марина Николаевна; Козиненко Наталия Михайловна", "license": "CC BY-NC 4.0", "titleEn": "Earthquake Catalog of the Crimean-Black Sea Region for 2024", "xmlPath": "", "position": 0, "authorsEn": "Bondar Marina Nikolaevna; Kozinenko Natalia Mikhailovna", "annotation": "Каталог землетрясений Крымско-Черноморского региона содержит основные параметры сейсмических событий природного происхождения, зарегистрированные крымской сетью станций в пределах границ региона. В 2024 году каталог состоит из 47 землетрясений с M≥0.8, в который, в качестве основных решений, перенесены параметры четырнадцати сейсмических событий из каталога Северо-Кавказского региона, а также добавлены альтернативные решения шести землетрясений.", "recordType": "dataset", "creatorName": "Сдельникова Ирина Александровна", "journalCode": "upp", "affiliations": "ISG CFU; ISG CFU", "bibliography": "", "citationLink": "Бондарь М.Н., Козиненко Н.М. Каталог землетрясений Крымско-Черноморского региона за 2024 год [Электронный ресурс] // Репозиторий геофизических данных. – Обнинск: ФИЦ ЕГС РАН, 2026. – DOI: 10.35540/gsras.upp.2026.1.01", "creatorEmail": "sdelnikova@gsras.ru", "documentType": "dataset", "organization": "ИСГ КФУ; ИСГ КФУ", "articleNumber": "01", "authorEntries": [{"id": "author-1780993161783-ed33ddc7504e28", "authorEn": "Bondar Marina Nikolaevna", "authorRu": "Бондарь Марина Николаевна", "organizationEn": "ISG CFU", "organizationRu": "ИСГ КФУ", "referenceAuthorId": 69, "organizationFullEn": "Institute of seismology and geodynamics of the Federal State Autonomous Educational Institution of Higher Education \\"V.I. Vernadsky Crimean Federal University\\"", "organizationFullRu": "Институт сейсмологии и геодинамики федерального государственного автономного образовательного учреждения высшего образования \\"Крымский федеральный университет имени В.И. Вернадского\\"", "referenceOrganizationId": 10}, {"id": "author-1780993181288-885e765c673a2", "authorEn": "Kozinenko Natalia Mikhailovna", "authorRu": "Козиненко Наталия Михайловна", "organizationEn": "ISG CFU", "organizationRu": "ИСГ КФУ", "referenceAuthorId": 70, "organizationFullEn": "Institute of seismology and geodynamics of the Federal State Autonomous Educational Institution of Higher Education \\"V.I. Vernadsky Crimean Federal University\\"", "organizationFullRu": "Институт сейсмологии и геодинамики федерального государственного автономного образовательного учреждения высшего образования \\"Крымский федеральный университет имени В.И. Вернадского\\"", "referenceOrganizationId": 10}], "creatorUserId": "4", "descriptionEn": "The Crimea-Black Sea region earthquake catalog contains the main parameters of natural seismic events recorded by the Crimean network of stations within the region's boundaries. In 2024, the catalog consists of 47 earthquakes with M≥0.8, with the parameters of fourteen seismic events from the North Caucasus region catalog transferred as primary solutions, as well as alternative solutions for six earthquakes.", "citationLinkEn": "Bondar M.N., Kozinenko N.M. (2026). Earthquake Catalog of the Crimean-Black Sea Region for 2024. Geophysical Data Repository, Geophysical Survey of the Russian Academy of Sciences, Obninsk, https://doi.org/10.35540/gsras.upp.2026.1.01", "organizationEn": "ISG CFU; ISG CFU", "publicationDate": "2026-06-09", "publicationYear": "2026", "revisionComment": "", "reviewEditorName": "", "reviewEditorEmail": "", "revisionCommentAuthor": "", "revisionCommentUpdatedAt": ""}	[{"id": "file-1780993161783-55ee1ffcf898f", "url": "/uploads/repository/2026/7a71692f-1fad-47ef-b324-d4b846e864a7/2024-ER_App01_Crimean-Black-Sea-region_Крым.xlsx", "type": "file", "label": "2024-ER_App01_Crimean-Black-Sea-region_Крым", "fileName": "2024-ER_App01_Crimean-Black-Sea-region_Крым.xlsx", "fileSize": 41613, "mimeType": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "placement": "meta", "sourceUrl": ""}]	2026-06-25 13:10:06.851	2026-06-09 11:23:29.417113	2026-06-26 15:49:59.377825	draft	\N	\N
\.


--
-- Data for Name: repositoryauthororganizations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repositoryauthororganizations (id, author_id, organization_id, status, requested_by_user_id, approved_by, approved_at, created_at, updated_at) FROM stdin;
1	1	1	approved	5	1	2026-05-04 10:55:33.387087	2026-04-30 10:38:38.127191	2026-05-04 10:55:33.387087
79	75	8	approved	\N	1	2026-05-29 11:00:42.37487	2026-05-29 11:00:42.37487	2026-05-29 11:00:42.37487
80	76	8	approved	\N	1	2026-05-29 11:00:42.46777	2026-05-29 11:00:42.46777	2026-05-29 11:00:42.46777
4	3	2	approved	\N	1	2026-05-22 11:57:04.938372	2026-05-22 11:57:04.938372	2026-05-22 11:57:04.938372
8	4	1	approved	\N	1	2026-05-28 13:39:19.471516	2026-05-28 13:39:19.471516	2026-05-28 13:39:19.471516
10	7	14	approved	\N	1	2026-05-29 11:00:35.295465	2026-05-29 11:00:35.295465	2026-05-29 11:00:35.295465
11	8	18	approved	\N	1	2026-05-29 11:00:35.452344	2026-05-29 11:00:35.452344	2026-05-29 11:00:35.452344
12	9	5	approved	\N	1	2026-05-29 11:00:35.548591	2026-05-29 11:00:35.548591	2026-05-29 11:00:35.548591
13	10	5	approved	\N	1	2026-05-29 11:00:35.655027	2026-05-29 11:00:35.655027	2026-05-29 11:00:35.655027
14	11	12	approved	\N	1	2026-05-29 11:00:35.754023	2026-05-29 11:00:35.754023	2026-05-29 11:00:35.754023
15	12	12	approved	\N	1	2026-05-29 11:00:35.8562	2026-05-29 11:00:35.8562	2026-05-29 11:00:35.8562
16	13	1	approved	\N	1	2026-05-29 11:00:35.951751	2026-05-29 11:00:35.951751	2026-05-29 11:00:35.951751
17	14	16	approved	\N	1	2026-05-29 11:00:36.051203	2026-05-29 11:00:36.051203	2026-05-29 11:00:36.051203
18	15	1	approved	\N	1	2026-05-29 11:00:36.147579	2026-05-29 11:00:36.147579	2026-05-29 11:00:36.147579
19	16	17	approved	\N	1	2026-05-29 11:00:36.248527	2026-05-29 11:00:36.248527	2026-05-29 11:00:36.248527
20	17	1	approved	\N	1	2026-05-29 11:00:36.360082	2026-05-29 11:00:36.360082	2026-05-29 11:00:36.360082
21	18	2	approved	\N	1	2026-05-29 11:00:36.456661	2026-05-29 11:00:36.456661	2026-05-29 11:00:36.456661
22	19	14	approved	\N	1	2026-05-29 11:00:36.549778	2026-05-29 11:00:36.549778	2026-05-29 11:00:36.549778
23	20	16	approved	\N	1	2026-05-29 11:00:36.646081	2026-05-29 11:00:36.646081	2026-05-29 11:00:36.646081
24	21	5	approved	\N	1	2026-05-29 11:00:36.741414	2026-05-29 11:00:36.741414	2026-05-29 11:00:36.741414
25	22	2	approved	\N	1	2026-05-29 11:00:36.83901	2026-05-29 11:00:36.83901	2026-05-29 11:00:36.83901
26	23	16	approved	\N	1	2026-05-29 11:00:36.934305	2026-05-29 11:00:36.934305	2026-05-29 11:00:36.934305
27	24	7	approved	\N	1	2026-05-29 11:00:37.033736	2026-05-29 11:00:37.033736	2026-05-29 11:00:37.033736
28	25	2	approved	\N	1	2026-05-29 11:00:37.152712	2026-05-29 11:00:37.152712	2026-05-29 11:00:37.152712
29	26	16	approved	\N	1	2026-05-29 11:00:37.255751	2026-05-29 11:00:37.255751	2026-05-29 11:00:37.255751
30	27	18	approved	\N	1	2026-05-29 11:00:37.352489	2026-05-29 11:00:37.352489	2026-05-29 11:00:37.352489
31	28	5	approved	\N	1	2026-05-29 11:00:37.470852	2026-05-29 11:00:37.470852	2026-05-29 11:00:37.470852
32	29	1	approved	\N	1	2026-05-29 11:00:37.56393	2026-05-29 11:00:37.56393	2026-05-29 11:00:37.56393
33	30	7	approved	\N	1	2026-05-29 11:00:37.674207	2026-05-29 11:00:37.674207	2026-05-29 11:00:37.674207
34	31	2	approved	\N	1	2026-05-29 11:00:37.767683	2026-05-29 11:00:37.767683	2026-05-29 11:00:37.767683
35	32	1	approved	\N	1	2026-05-29 11:00:37.902332	2026-05-29 11:00:37.902332	2026-05-29 11:00:37.902332
36	33	1	approved	\N	1	2026-05-29 11:00:38.000094	2026-05-29 11:00:38.000094	2026-05-29 11:00:38.000094
37	34	1	approved	\N	1	2026-05-29 11:00:38.100556	2026-05-29 11:00:38.100556	2026-05-29 11:00:38.100556
38	35	1	approved	\N	1	2026-05-29 11:00:38.194468	2026-05-29 11:00:38.194468	2026-05-29 11:00:38.194468
39	36	12	approved	\N	1	2026-05-29 11:00:38.296582	2026-05-29 11:00:38.296582	2026-05-29 11:00:38.296582
40	37	2	approved	\N	1	2026-05-29 11:00:38.416469	2026-05-29 11:00:38.416469	2026-05-29 11:00:38.416469
41	38	16	approved	\N	1	2026-05-29 11:00:38.521229	2026-05-29 11:00:38.521229	2026-05-29 11:00:38.521229
42	39	1	approved	\N	1	2026-05-29 11:00:38.640831	2026-05-29 11:00:38.640831	2026-05-29 11:00:38.640831
43	40	1	approved	\N	1	2026-05-29 11:00:38.745289	2026-05-29 11:00:38.745289	2026-05-29 11:00:38.745289
44	41	16	approved	\N	1	2026-05-29 11:00:38.858494	2026-05-29 11:00:38.858494	2026-05-29 11:00:38.858494
45	42	16	approved	\N	1	2026-05-29 11:00:38.956624	2026-05-29 11:00:38.956624	2026-05-29 11:00:38.956624
46	43	16	approved	\N	1	2026-05-29 11:00:39.057966	2026-05-29 11:00:39.057966	2026-05-29 11:00:39.057966
47	44	1	approved	\N	1	2026-05-29 11:00:39.155649	2026-05-29 11:00:39.155649	2026-05-29 11:00:39.155649
48	45	18	approved	\N	1	2026-05-29 11:00:39.252398	2026-05-29 11:00:39.252398	2026-05-29 11:00:39.252398
49	46	5	approved	\N	1	2026-05-29 11:00:39.358154	2026-05-29 11:00:39.358154	2026-05-29 11:00:39.358154
50	47	1	approved	\N	1	2026-05-29 11:00:39.453948	2026-05-29 11:00:39.453948	2026-05-29 11:00:39.453948
51	48	9	approved	\N	1	2026-05-29 11:00:39.57098	2026-05-29 11:00:39.57098	2026-05-29 11:00:39.57098
52	49	16	approved	\N	1	2026-05-29 11:00:39.665369	2026-05-29 11:00:39.665369	2026-05-29 11:00:39.665369
53	50	1	approved	\N	1	2026-05-29 11:00:39.768537	2026-05-29 11:00:39.768537	2026-05-29 11:00:39.768537
54	51	1	approved	\N	1	2026-05-29 11:00:39.868348	2026-05-29 11:00:39.868348	2026-05-29 11:00:39.868348
55	52	1	approved	\N	1	2026-05-29 11:00:39.97426	2026-05-29 11:00:39.97426	2026-05-29 11:00:39.97426
56	53	5	approved	\N	1	2026-05-29 11:00:40.074114	2026-05-29 11:00:40.074114	2026-05-29 11:00:40.074114
57	54	2	approved	\N	1	2026-05-29 11:00:40.179459	2026-05-29 11:00:40.179459	2026-05-29 11:00:40.179459
58	55	16	approved	\N	1	2026-05-29 11:00:40.277937	2026-05-29 11:00:40.277937	2026-05-29 11:00:40.277937
59	56	16	approved	\N	1	2026-05-29 11:00:40.378916	2026-05-29 11:00:40.378916	2026-05-29 11:00:40.378916
60	57	16	approved	\N	1	2026-05-29 11:00:40.473733	2026-05-29 11:00:40.473733	2026-05-29 11:00:40.473733
61	58	1	approved	\N	1	2026-05-29 11:00:40.577823	2026-05-29 11:00:40.577823	2026-05-29 11:00:40.577823
62	59	18	approved	\N	1	2026-05-29 11:00:40.67294	2026-05-29 11:00:40.67294	2026-05-29 11:00:40.67294
63	60	16	approved	\N	1	2026-05-29 11:00:40.772518	2026-05-29 11:00:40.772518	2026-05-29 11:00:40.772518
64	61	5	approved	\N	1	2026-05-29 11:00:40.874855	2026-05-29 11:00:40.874855	2026-05-29 11:00:40.874855
65	62	18	approved	\N	1	2026-05-29 11:00:40.976349	2026-05-29 11:00:40.976349	2026-05-29 11:00:40.976349
66	63	14	approved	\N	1	2026-05-29 11:00:41.072359	2026-05-29 11:00:41.072359	2026-05-29 11:00:41.072359
67	64	5	approved	\N	1	2026-05-29 11:00:41.172371	2026-05-29 11:00:41.172371	2026-05-29 11:00:41.172371
68	65	5	approved	\N	1	2026-05-29 11:00:41.268187	2026-05-29 11:00:41.268187	2026-05-29 11:00:41.268187
69	66	7	approved	\N	1	2026-05-29 11:00:41.384994	2026-05-29 11:00:41.384994	2026-05-29 11:00:41.384994
70	67	16	approved	\N	1	2026-05-29 11:00:41.490397	2026-05-29 11:00:41.490397	2026-05-29 11:00:41.490397
72	69	10	approved	\N	1	2026-05-29 11:00:41.680402	2026-05-29 11:00:41.680402	2026-05-29 11:00:41.680402
73	70	10	approved	\N	1	2026-05-29 11:00:41.776291	2026-05-29 11:00:41.776291	2026-05-29 11:00:41.776291
74	5	1	approved	\N	1	2026-05-29 11:00:41.880633	2026-05-29 11:00:41.880633	2026-05-29 11:00:41.880633
75	71	8	approved	\N	1	2026-05-29 11:00:41.98008	2026-05-29 11:00:41.98008	2026-05-29 11:00:41.98008
76	72	15	approved	\N	1	2026-05-29 11:00:42.075705	2026-05-29 11:00:42.075705	2026-05-29 11:00:42.075705
77	73	15	approved	\N	1	2026-05-29 11:00:42.180837	2026-05-29 11:00:42.180837	2026-05-29 11:00:42.180837
78	74	1	approved	\N	1	2026-05-29 11:00:42.273989	2026-05-29 11:00:42.273989	2026-05-29 11:00:42.273989
81	77	8	approved	\N	1	2026-05-29 11:00:42.56555	2026-05-29 11:00:42.56555	2026-05-29 11:00:42.56555
82	78	8	approved	\N	1	2026-05-29 11:00:42.665901	2026-05-29 11:00:42.665901	2026-05-29 11:00:42.665901
83	79	8	approved	\N	1	2026-05-29 11:00:42.762758	2026-05-29 11:00:42.762758	2026-05-29 11:00:42.762758
84	80	8	approved	\N	1	2026-05-29 11:00:42.856947	2026-05-29 11:00:42.856947	2026-05-29 11:00:42.856947
85	81	15	approved	\N	1	2026-05-29 11:00:42.95796	2026-05-29 11:00:42.95796	2026-05-29 11:00:42.95796
86	82	15	approved	\N	1	2026-05-29 11:00:43.052855	2026-05-29 11:00:43.052855	2026-05-29 11:00:43.052855
87	83	12	approved	\N	1	2026-05-29 11:00:43.15198	2026-05-29 11:00:43.15198	2026-05-29 11:00:43.15198
88	84	11	approved	\N	1	2026-05-29 11:00:43.251881	2026-05-29 11:00:43.251881	2026-05-29 11:00:43.251881
89	85	1	approved	\N	1	2026-05-29 11:00:43.354124	2026-05-29 11:00:43.354124	2026-05-29 11:00:43.354124
90	86	6	approved	\N	1	2026-05-29 11:00:43.463464	2026-05-29 11:00:43.463464	2026-05-29 11:00:43.463464
91	87	6	approved	\N	1	2026-05-29 11:00:43.565378	2026-05-29 11:00:43.565378	2026-05-29 11:00:43.565378
92	88	6	approved	\N	1	2026-05-29 11:00:43.985624	2026-05-29 11:00:43.985624	2026-05-29 11:00:43.985624
93	89	6	approved	\N	1	2026-05-29 11:00:44.121145	2026-05-29 11:00:44.121145	2026-05-29 11:00:44.121145
94	90	6	approved	\N	1	2026-05-29 11:00:44.214165	2026-05-29 11:00:44.214165	2026-05-29 11:00:44.214165
95	91	6	approved	\N	1	2026-05-29 11:00:44.311098	2026-05-29 11:00:44.311098	2026-05-29 11:00:44.311098
96	92	6	approved	\N	1	2026-05-29 11:00:44.412065	2026-05-29 11:00:44.412065	2026-05-29 11:00:44.412065
97	93	6	approved	\N	1	2026-05-29 11:00:44.509373	2026-05-29 11:00:44.509373	2026-05-29 11:00:44.509373
98	94	6	approved	\N	1	2026-05-29 11:00:44.604007	2026-05-29 11:00:44.604007	2026-05-29 11:00:44.604007
99	95	6	approved	\N	1	2026-05-29 11:00:44.703766	2026-05-29 11:00:44.703766	2026-05-29 11:00:44.703766
100	96	16	approved	\N	1	2026-05-29 11:00:44.806842	2026-05-29 11:00:44.806842	2026-05-29 11:00:44.806842
101	97	16	approved	\N	1	2026-05-29 11:00:44.907903	2026-05-29 11:00:44.907903	2026-05-29 11:00:44.907903
102	98	16	approved	\N	1	2026-05-29 11:00:45.011208	2026-05-29 11:00:45.011208	2026-05-29 11:00:45.011208
103	99	16	approved	\N	1	2026-05-29 11:00:45.117654	2026-05-29 11:00:45.117654	2026-05-29 11:00:45.117654
104	100	18	approved	\N	1	2026-05-29 11:00:45.223854	2026-05-29 11:00:45.223854	2026-05-29 11:00:45.223854
105	101	18	approved	\N	1	2026-05-29 11:00:45.325314	2026-05-29 11:00:45.325314	2026-05-29 11:00:45.325314
106	102	13	approved	\N	1	2026-05-29 11:00:45.427543	2026-05-29 11:00:45.427543	2026-05-29 11:00:45.427543
107	103	13	approved	\N	1	2026-05-29 11:00:45.535068	2026-05-29 11:00:45.535068	2026-05-29 11:00:45.535068
108	104	13	approved	\N	1	2026-05-29 11:00:45.643964	2026-05-29 11:00:45.643964	2026-05-29 11:00:45.643964
109	105	13	approved	\N	1	2026-05-29 11:00:45.745858	2026-05-29 11:00:45.745858	2026-05-29 11:00:45.745858
110	106	13	approved	\N	1	2026-05-29 11:00:45.841094	2026-05-29 11:00:45.841094	2026-05-29 11:00:45.841094
111	107	13	approved	\N	1	2026-05-29 11:00:45.940625	2026-05-29 11:00:45.940625	2026-05-29 11:00:45.940625
112	108	13	approved	\N	1	2026-05-29 11:00:46.073982	2026-05-29 11:00:46.073982	2026-05-29 11:00:46.073982
113	109	12	approved	\N	1	2026-05-29 11:00:46.172526	2026-05-29 11:00:46.172526	2026-05-29 11:00:46.172526
115	111	6	approved	\N	1	2026-05-29 11:00:46.380229	2026-05-29 11:00:46.380229	2026-05-29 11:00:46.380229
116	112	13	approved	\N	1	2026-05-29 11:00:46.475132	2026-05-29 11:00:46.475132	2026-05-29 11:00:46.475132
117	113	1	approved	\N	1	2026-05-29 11:00:46.574942	2026-05-29 11:00:46.574942	2026-05-29 11:00:46.574942
118	114	16	approved	\N	1	2026-05-29 11:00:46.68034	2026-05-29 11:00:46.68034	2026-05-29 11:00:46.68034
119	115	1	approved	\N	1	2026-05-29 11:00:46.777421	2026-05-29 11:00:46.777421	2026-05-29 11:00:46.777421
120	116	1	approved	\N	1	2026-05-29 11:00:46.878747	2026-05-29 11:00:46.878747	2026-05-29 11:00:46.878747
122	110	13	approved	\N	1	2026-05-29 12:17:31.053237	2026-05-29 12:17:31.053237	2026-05-29 12:17:31.053237
124	68	16	approved	\N	4	2026-06-05 12:13:23.293117	2026-06-05 12:13:23.293117	2026-06-05 12:13:23.293117
\.


--
-- Data for Name: repositoryauthors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repositoryauthors (id, name_ru, name_en, status, requested_by_user_id, requester_name, requester_email, approved_by, approved_at, created_at, updated_at) FROM stdin;
1	Сдельникова Ирина Александровна	Sdelnikova Irina	approved	5	Сдельникова Ирина Александровна	us@gsras.ru	1	2026-05-04 10:55:33.387087	2026-04-30 10:38:38.127191	2026-05-04 10:55:33.387087
27	Денега Елена Григорьевна	Denega Elena Grigorievna	approved	\N	\N	\N	1	2026-05-29 11:00:37.352489	2026-05-29 11:00:37.352489	2026-05-29 11:00:37.352489
28	Еманов Алексей Александрович	Emanov Alexey Alexandrovich	approved	\N	\N	\N	1	2026-05-29 11:00:37.470852	2026-05-29 11:00:37.470852	2026-05-29 11:00:37.470852
29	Ефременко Марина Алексеевна	Efremenko Marina Alekseevna	approved	\N	\N	\N	1	2026-05-29 11:00:37.56393	2026-05-29 11:00:37.56393	2026-05-29 11:00:37.56393
30	Злобина Татьяна Викторовна	Zlobina Tatiyana Victorovna	approved	\N	\N	\N	1	2026-05-29 11:00:37.674207	2026-05-29 11:00:37.674207	2026-05-29 11:00:37.674207
31	Иванов Алексей Григорьевич	Ivanov Alexey Grigorievich	approved	\N	\N	\N	1	2026-05-29 11:00:37.767683	2026-05-29 11:00:37.767683	2026-05-29 11:00:37.767683
32	Иванова Людмила Евгеньевна	Ivanova Lyudmila Evgenievna	approved	\N	\N	\N	1	2026-05-29 11:00:37.902332	2026-05-29 11:00:37.902332	2026-05-29 11:00:37.902332
33	Карпинская Ольга Валентиновна	Karpinskaia Olga Valentinovna	approved	\N	\N	\N	1	2026-05-29 11:00:38.000094	2026-05-29 11:00:38.000094	2026-05-29 11:00:38.000094
3	Китов Иван Олегович	Kitov Ivan Olegovich	approved	7	Сдельникова Ирина Александровна	newsbox@gsras.ru	1	2026-05-22 11:57:04.938372	2026-05-19 14:51:18.776947	2026-05-22 11:57:04.938372
34	Карпинский Владимир Вадимович	Karpinsky Vladimir Vadimovich	approved	\N	\N	\N	1	2026-05-29 11:00:38.100556	2026-05-29 11:00:38.100556	2026-05-29 11:00:38.100556
35	Клянчин Андрей Игоревич	Klyanchin Andrej Igorevich	approved	\N	\N	\N	1	2026-05-29 11:00:38.194468	2026-05-29 11:00:38.194468	2026-05-29 11:00:38.194468
36	Коломиец Ольга Анатольевна	Kolomiets Olga Anatolyevna	approved	\N	\N	\N	1	2026-05-29 11:00:38.296582	2026-05-29 11:00:38.296582	2026-05-29 11:00:38.296582
4	Санина Ирина Альфатовна	Sanina Irina Alfatovna	approved	7	Сдельникова Ирина Александровна	newsbox@gsras.ru	1	2026-05-28 13:39:19.471516	2026-05-19 14:55:05.301715	2026-05-28 13:39:19.471516
7	Алёшина Евгения Ильинична	Alyeshina Evgeniya Ilyinichna	approved	\N	\N	\N	1	2026-05-29 11:00:35.295465	2026-05-29 11:00:35.295465	2026-05-29 11:00:35.295465
8	Андреева Сусанна Анваровна	Andreeva Susanna Anvarovna	approved	\N	\N	\N	1	2026-05-29 11:00:35.452344	2026-05-29 11:00:35.452344	2026-05-29 11:00:35.452344
9	Арапов Виктор Владимирович	Arapov Viktor Vladimirovich	approved	\N	\N	\N	1	2026-05-29 11:00:35.548591	2026-05-29 11:00:35.548591	2026-05-29 11:00:35.548591
10	Артёмова Анна Игоревна	Artemova Anna Igorevna	approved	\N	\N	\N	1	2026-05-29 11:00:35.655027	2026-05-29 11:00:35.655027	2026-05-29 11:00:35.655027
11	Асминг Владимир Эрнестович	Asming Vladimir Ernestovich	approved	\N	\N	\N	1	2026-05-29 11:00:35.754023	2026-05-29 11:00:35.754023	2026-05-29 11:00:35.754023
12	Баранов Сергей Владимирович	Baranov Sergey Vladimirovich	approved	\N	\N	\N	1	2026-05-29 11:00:35.8562	2026-05-29 11:00:35.8562	2026-05-29 11:00:35.8562
13	Белевская Мария Александровна	Belevskaya Mariya Aleksandrovna	approved	\N	\N	\N	1	2026-05-29 11:00:35.951751	2026-05-29 11:00:35.951751	2026-05-29 11:00:35.951751
14	Бернвальд Татьяна Анатольевна	Bernvald Tatiana Anatolyevna	approved	\N	\N	\N	1	2026-05-29 11:00:36.051203	2026-05-29 11:00:36.051203	2026-05-29 11:00:36.051203
15	Будеева Наталья Валентиновна	Budeeva Natalia Valentinovna	approved	\N	\N	\N	1	2026-05-29 11:00:36.147579	2026-05-29 11:00:36.147579	2026-05-29 11:00:36.147579
16	Ваганова Наталья Владиславовна	Vaganova Natalia Vladislavovna	approved	\N	\N	\N	1	2026-05-29 11:00:36.248527	2026-05-29 11:00:36.248527	2026-05-29 11:00:36.248527
17	Верхоланцев Филипп Геннадьевич	Verkholantsev Filipp Gennadievich	approved	\N	\N	\N	1	2026-05-29 11:00:36.360082	2026-05-29 11:00:36.360082	2026-05-29 11:00:36.360082
18	Волосов Сергей Георгиевич	Volosov Sergey Georgievich	approved	\N	\N	\N	1	2026-05-29 11:00:36.456661	2026-05-29 11:00:36.456661	2026-05-29 11:00:36.456661
19	Габдрахманова Юлия Викторовна	Gabdrakhmanova Julia Viktorovna	approved	\N	\N	\N	1	2026-05-29 11:00:36.549778	2026-05-29 11:00:36.549778	2026-05-29 11:00:36.549778
20	Гарькина Дарья Алексеевна	Garkina Darya Alekseevna	approved	\N	\N	\N	1	2026-05-29 11:00:36.646081	2026-05-29 11:00:36.646081	2026-05-29 11:00:36.646081
21	Гладышев Егор Андреевич	Gladyshev Egor Andreevich	approved	\N	\N	\N	1	2026-05-29 11:00:36.741414	2026-05-29 11:00:36.741414	2026-05-29 11:00:36.741414
22	Гоев Андрей Георгиевич	Goev Andrey Georgievich	approved	\N	\N	\N	1	2026-05-29 11:00:36.83901	2026-05-29 11:00:36.83901	2026-05-29 11:00:36.83901
23	Григорьева Ольга Олеговна	Grigorieva Olga Olegovna	approved	\N	\N	\N	1	2026-05-29 11:00:36.934305	2026-05-29 11:00:36.934305	2026-05-29 11:00:36.934305
24	Гусева Наталья Сергеевна	Guseva Nataliya Sergeevna	approved	\N	\N	\N	1	2026-05-29 11:00:37.033736	2026-05-29 11:00:37.033736	2026-05-29 11:00:37.033736
25	Данилова Татьяна Валерьевна	Danilova Tatiana Valeryevna	approved	\N	\N	\N	1	2026-05-29 11:00:37.152712	2026-05-29 11:00:37.152712	2026-05-29 11:00:37.152712
26	Дашковский Константин Олегович	Dashkovsky Konstantin Olegovich	approved	\N	\N	\N	1	2026-05-29 11:00:37.255751	2026-05-29 11:00:37.255751	2026-05-29 11:00:37.255751
37	Константиновская Наталья Львовна	Konstantinovskaya Natalia Lvovna	approved	\N	\N	\N	1	2026-05-29 11:00:38.416469	2026-05-29 11:00:38.416469	2026-05-29 11:00:38.416469
38	Коргун Наталья Викторовна	Korgun Natalia Viktorovna	approved	\N	\N	\N	1	2026-05-29 11:00:38.521229	2026-05-29 11:00:38.521229	2026-05-29 11:00:38.521229
39	Королецки Людмила Николаевна	Korolecki Lyudmila Nikolaevna	approved	\N	\N	\N	1	2026-05-29 11:00:38.640831	2026-05-29 11:00:38.640831	2026-05-29 11:00:38.640831
40	Косая Вера Викторовна	Kosaya Vera Viktorovna	approved	\N	\N	\N	1	2026-05-29 11:00:38.745289	2026-05-29 11:00:38.745289	2026-05-29 11:00:38.745289
41	Костылева Наталья Владимировна	Kostyleva Natalia Vladimirovna	approved	\N	\N	\N	1	2026-05-29 11:00:38.858494	2026-05-29 11:00:38.858494	2026-05-29 11:00:38.858494
42	Кругова Ирина Петровна	Krugova Irina Petrovna	approved	\N	\N	\N	1	2026-05-29 11:00:38.956624	2026-05-29 11:00:38.956624	2026-05-29 11:00:38.956624
43	Кускова Наталья Александровна	Kuskova Natalia Alexandrovna	approved	\N	\N	\N	1	2026-05-29 11:00:39.057966	2026-05-29 11:00:39.057966	2026-05-29 11:00:39.057966
44	Лещук Надежда Максимовна	Leshchuk Nadezhda Maksimovna	approved	\N	\N	\N	1	2026-05-29 11:00:39.155649	2026-05-29 11:00:39.155649	2026-05-29 11:00:39.155649
45	Макаров Александр Александрович	Makarov Alexander Alexandrovich	approved	\N	\N	\N	1	2026-05-29 11:00:39.252398	2026-05-29 11:00:39.252398	2026-05-29 11:00:39.252398
46	Манушина Ольга Адушевна	Manushina Olga Adushevna	approved	\N	\N	\N	1	2026-05-29 11:00:39.358154	2026-05-29 11:00:39.358154	2026-05-29 11:00:39.358154
47	Мунирова Лира Мирхатовна	Munirova Lyra Mirkhatovna	approved	\N	\N	\N	1	2026-05-29 11:00:39.453948	2026-05-29 11:00:39.453948	2026-05-29 11:00:39.453948
48	Носкова Наталия Николаевна	Noskova Natalia Nikolaevna	approved	\N	\N	\N	1	2026-05-29 11:00:39.57098	2026-05-29 11:00:39.57098	2026-05-29 11:00:39.57098
49	Паршина Инна Анатольевна	Parshina Inna Anatolyevna	approved	\N	\N	\N	1	2026-05-29 11:00:39.665369	2026-05-29 11:00:39.665369	2026-05-29 11:00:39.665369
50	Петросян Элла Назаровна	Petrosyan Ehlla Nazarovna	approved	\N	\N	\N	1	2026-05-29 11:00:39.768537	2026-05-29 11:00:39.768537	2026-05-29 11:00:39.768537
51	Пивоваров Роман Сергеевич	Pivovarov Roman Sergeevich	approved	\N	\N	\N	1	2026-05-29 11:00:39.868348	2026-05-29 11:00:39.868348	2026-05-29 11:00:39.868348
52	Пивоваров Сергей Павлович	Pivovarov Sergey Pavlovich	approved	\N	\N	\N	1	2026-05-29 11:00:39.97426	2026-05-29 11:00:39.97426	2026-05-29 11:00:39.97426
53	Подлипская Лиляна Анатольевна	Podlipskaya Liliana Anatolyevna	approved	\N	\N	\N	1	2026-05-29 11:00:40.074114	2026-05-29 11:00:40.074114	2026-05-29 11:00:40.074114
54	Резниченко Роман Александрович	Reznichenko Roman Alexandrovich	approved	\N	\N	\N	1	2026-05-29 11:00:40.179459	2026-05-29 11:00:40.179459	2026-05-29 11:00:40.179459
55	Рунова Анна Игоревна	Runova Anna Igorevna	approved	\N	\N	\N	1	2026-05-29 11:00:40.277937	2026-05-29 11:00:40.277937	2026-05-29 11:00:40.277937
56	Семенова Елена Петровна	Semenova Elena Petrovna	approved	\N	\N	\N	1	2026-05-29 11:00:40.378916	2026-05-29 11:00:40.378916	2026-05-29 11:00:40.378916
57	Сон Александр	Son Alexander	approved	\N	\N	\N	1	2026-05-29 11:00:40.473733	2026-05-29 11:00:40.473733	2026-05-29 11:00:40.473733
58	Старикович Екатерина Николаевна	Starikovich Ekaterina Nikolaevna	approved	\N	\N	\N	1	2026-05-29 11:00:40.577823	2026-05-29 11:00:40.577823	2026-05-29 11:00:40.577823
59	Старкова Нюргустана Николаевна	Starkova Nyurgustana Nikolaevna	approved	\N	\N	\N	1	2026-05-29 11:00:40.67294	2026-05-29 11:00:40.67294	2026-05-29 11:00:40.67294
60	Терентьева Оксана Евгеньевна	Terentyeva Oksana Evgenievna	approved	\N	\N	\N	1	2026-05-29 11:00:40.772518	2026-05-29 11:00:40.772518	2026-05-29 11:00:40.772518
61	Фролов Михаил Владимирович	Frolov Mikhail Vladimirovich	approved	\N	\N	\N	1	2026-05-29 11:00:40.874855	2026-05-29 11:00:40.874855	2026-05-29 11:00:40.874855
62	Хастаева Елена Валентиновна	Hastaeva Elena Valentinovna	approved	\N	\N	\N	1	2026-05-29 11:00:40.976349	2026-05-29 11:00:40.976349	2026-05-29 11:00:40.976349
63	Чернецова Анна Геннадьевна	Chernetsova Anna Gennadievna	approved	\N	\N	\N	1	2026-05-29 11:00:41.072359	2026-05-29 11:00:41.072359	2026-05-29 11:00:41.072359
64	Шаталова Алена Олеговна	Shatalova Alena Olegovna	approved	\N	\N	\N	1	2026-05-29 11:00:41.172371	2026-05-29 11:00:41.172371	2026-05-29 11:00:41.172371
65	Шевкунова Елена Викторовна	Shevkunova Elena Viktorovna	approved	\N	\N	\N	1	2026-05-29 11:00:41.268187	2026-05-29 11:00:41.268187	2026-05-29 11:00:41.268187
66	Шулаков Денис Юрьевич	Shulakov Denis Yurievich	approved	\N	\N	\N	1	2026-05-29 11:00:41.384994	2026-05-29 11:00:41.384994	2026-05-29 11:00:41.384994
67	Ягубцев Дмитрий Николаевич	Yagubtsev Dmitry Nikolaevich	approved	\N	\N	\N	1	2026-05-29 11:00:41.490397	2026-05-29 11:00:41.490397	2026-05-29 11:00:41.490397
69	Бондарь Марина Николаевна	Bondar Marina Nikolaevna	approved	\N	\N	\N	1	2026-05-29 11:00:41.680402	2026-05-29 11:00:41.680402	2026-05-29 11:00:41.680402
70	Козиненко Наталия Михайловна	Kozinenko Natalia Mikhailovna	approved	\N	\N	\N	1	2026-05-29 11:00:41.776291	2026-05-29 11:00:41.776291	2026-05-29 11:00:41.776291
5	Габсатарова Ирина Петровна	Gabsatarova Irina Petrovna	approved	7	Сдельникова Ирина Александровна	newsbox@gsras.ru	1	2026-05-29 11:00:41.880633	2026-05-19 14:57:46.914651	2026-05-29 11:00:41.880633
71	Адилов Зарахман Ашуралиевич	Adilov Zarahman Ashuralievich	approved	\N	\N	\N	1	2026-05-29 11:00:41.98008	2026-05-29 11:00:41.98008	2026-05-29 11:00:41.98008
72	Саяпина Анна Анатольевна	Sayapina Anna Anatolyevna	approved	\N	\N	\N	1	2026-05-29 11:00:42.075705	2026-05-29 11:00:42.075705	2026-05-29 11:00:42.075705
73	Багаева Софья Сергеевна	Bagaeva Sofia Sergeevna	approved	\N	\N	\N	1	2026-05-29 11:00:42.180837	2026-05-29 11:00:42.180837	2026-05-29 11:00:42.180837
74	Александрова Любовь Иосифовна	Aleksandrova Lyubov Iosifovna	approved	\N	\N	\N	1	2026-05-29 11:00:42.273989	2026-05-29 11:00:42.273989	2026-05-29 11:00:42.273989
75	Асекова Зульфия Османовна	Asekova Zulfiya Osmanovna	approved	\N	\N	\N	1	2026-05-29 11:00:42.37487	2026-05-29 11:00:42.37487	2026-05-29 11:00:42.37487
76	Гамидова Айшат Магомедовна	Gamidova Ajshat Magomedovna	approved	\N	\N	\N	1	2026-05-29 11:00:42.46777	2026-05-29 11:00:42.46777	2026-05-29 11:00:42.46777
77	Мусалаева Земфира Абдуразаковна	Musalaeva Zemfira Abdurazakovna	approved	\N	\N	\N	1	2026-05-29 11:00:42.56555	2026-05-29 11:00:42.56555	2026-05-29 11:00:42.56555
78	Павличенко Ирина Николаевна	Pavlichenko Irina Nikolaevna	approved	\N	\N	\N	1	2026-05-29 11:00:42.665901	2026-05-29 11:00:42.665901	2026-05-29 11:00:42.665901
79	Сагателова Елена Юрьевна	Sagatelova Elena Yurievna	approved	\N	\N	\N	1	2026-05-29 11:00:42.762758	2026-05-29 11:00:42.762758	2026-05-29 11:00:42.762758
80	Шахмарданова Сапият Гаджиевна	Shahmardanova Sapiyat Gadzhievna	approved	\N	\N	\N	1	2026-05-29 11:00:42.856947	2026-05-29 11:00:42.856947	2026-05-29 11:00:42.856947
81	Дмитриева Изольда Юрьевна	Dmitrieva Isolda Yurievna	approved	\N	\N	\N	1	2026-05-29 11:00:42.95796	2026-05-29 11:00:42.95796	2026-05-29 11:00:42.95796
82	Чивиева Татьяна Валерьевна	Chivieva Tatyana Valerievna	approved	\N	\N	\N	1	2026-05-29 11:00:43.052855	2026-05-29 11:00:43.052855	2026-05-29 11:00:43.052855
83	Ковалева Ирина Сергеевна	Kovaleva Irina Sergeevna	approved	\N	\N	\N	1	2026-05-29 11:00:43.15198	2026-05-29 11:00:43.15198	2026-05-29 11:00:43.15198
84	Морозов Алексей Николаевич	Morozov Alexey Nikolaevich	approved	\N	\N	\N	1	2026-05-29 11:00:43.251881	2026-05-29 11:00:43.251881	2026-05-29 11:00:43.251881
85	Конечная Яна Викторовна	Konechnaya Yana Viktorovna	approved	\N	\N	\N	1	2026-05-29 11:00:43.354124	2026-05-29 11:00:43.354124	2026-05-29 11:00:43.354124
86	Гилёва Надежда Алексеевна	Gileva Nadezhda Alekseevna	approved	\N	\N	\N	1	2026-05-29 11:00:43.463464	2026-05-29 11:00:43.463464	2026-05-29 11:00:43.463464
87	Грачева Оксана Александровна	Gracheva Oksana Aleksandrovna	approved	\N	\N	\N	1	2026-05-29 11:00:43.565378	2026-05-29 11:00:43.565378	2026-05-29 11:00:43.565378
88	Меньшикова Юлия Александровна	Menshikova Yulia Aleksandrovna	approved	\N	\N	\N	1	2026-05-29 11:00:43.985624	2026-05-29 11:00:43.985624	2026-05-29 11:00:43.985624
89	Курилко Галина Васильевна	Kurilko Galina Vasilievna	approved	\N	\N	\N	1	2026-05-29 11:00:44.121145	2026-05-29 11:00:44.121145	2026-05-29 11:00:44.121145
90	Емельянова Лариса Владимировна	Emelyanova Larisa Vladimirovna	approved	\N	\N	\N	1	2026-05-29 11:00:44.214165	2026-05-29 11:00:44.214165	2026-05-29 11:00:44.214165
91	Архипенко Наталья Сергеевна	Archipenko Natalya Sergeevna	approved	\N	\N	\N	1	2026-05-29 11:00:44.311098	2026-05-29 11:00:44.311098	2026-05-29 11:00:44.311098
92	Сенотрусова Татьяна Евгеньевна	Senotrusova Tatyana Evgenievna	approved	\N	\N	\N	1	2026-05-29 11:00:44.412065	2026-05-29 11:00:44.412065	2026-05-29 11:00:44.412065
93	Ныркова Светлана Владимировна	Nyrkova Svetlana Vladimirovna	approved	\N	\N	\N	1	2026-05-29 11:00:44.509373	2026-05-29 11:00:44.509373	2026-05-29 11:00:44.509373
94	Ситникова Анна Анатольевна	Sitnikova Anna Anatolievna	approved	\N	\N	\N	1	2026-05-29 11:00:44.604007	2026-05-29 11:00:44.604007	2026-05-29 11:00:44.604007
95	Радзиминович Ян Борисович	Radziminovich Yan Borisovich	approved	\N	\N	\N	1	2026-05-29 11:00:44.703766	2026-05-29 11:00:44.703766	2026-05-29 11:00:44.703766
96	Дорошкевич Елена Николаевна	Doroshkevich Elena Nikolaevna	approved	\N	\N	\N	1	2026-05-29 11:00:44.806842	2026-05-29 11:00:44.806842	2026-05-29 11:00:44.806842
97	Карташова Ольга Леонидовна	Kartashova Olga Leonidovna	approved	\N	\N	\N	1	2026-05-29 11:00:44.907903	2026-05-29 11:00:44.907903	2026-05-29 11:00:44.907903
98	Лысенко Татьяна Николаевна	Lysenko Tatiana Nikolaevna	approved	\N	\N	\N	1	2026-05-29 11:00:45.011208	2026-05-29 11:00:45.011208	2026-05-29 11:00:45.011208
99	Швидская Светлана Васильевна	Shvidskaya Svetlana Vasilyevna	approved	\N	\N	\N	1	2026-05-29 11:00:45.117654	2026-05-29 11:00:45.117654	2026-05-29 11:00:45.117654
100	Куляндина Альбина Семеновна	Kulyandina Albina Semyonovna	approved	\N	\N	\N	1	2026-05-29 11:00:45.223854	2026-05-29 11:00:45.223854	2026-05-29 11:00:45.223854
101	Туктаров Рустам Мингулович	Tuktarov Rustam Mingulovich	approved	\N	\N	\N	1	2026-05-29 11:00:45.325314	2026-05-29 11:00:45.325314	2026-05-29 11:00:45.325314
102	Сенюков Сергей Львович	Senyukov Sergey Lvovich	approved	\N	\N	\N	1	2026-05-29 11:00:45.427543	2026-05-29 11:00:45.427543	2026-05-29 11:00:45.427543
103	Дрознина Светлана Ярославовна	Droznina Svetlana Yaroslavovna	approved	\N	\N	\N	1	2026-05-29 11:00:45.535068	2026-05-29 11:00:45.535068	2026-05-29 11:00:45.535068
104	Карпенко Елена Александровна	Karpenko Elena Alexandrovna	approved	\N	\N	\N	1	2026-05-29 11:00:45.643964	2026-05-29 11:00:45.643964	2026-05-29 11:00:45.643964
105	Леднева Наталья Александровна	Ledneva Natalia Alexandrovna	approved	\N	\N	\N	1	2026-05-29 11:00:45.745858	2026-05-29 11:00:45.745858	2026-05-29 11:00:45.745858
106	Должикова Анастасия Николаевна	Dolzhikova Anastasia Nikolaevna	approved	\N	\N	\N	1	2026-05-29 11:00:45.841094	2026-05-29 11:00:45.841094	2026-05-29 11:00:45.841094
107	Митюшкина Светлана Владимировна	Mityushkina Svetlana Vladimirovna	approved	\N	\N	\N	1	2026-05-29 11:00:45.940625	2026-05-29 11:00:45.940625	2026-05-29 11:00:45.940625
108	Раевская Анна Александровна	Raevskaya Anna Alexandrovna	approved	\N	\N	\N	1	2026-05-29 11:00:46.073982	2026-05-29 11:00:46.073982	2026-05-29 11:00:46.073982
109	Асминг Светлана Викторовна	Asming Svetlana Viktorovna	approved	\N	\N	\N	1	2026-05-29 11:00:46.172526	2026-05-29 11:00:46.172526	2026-05-29 11:00:46.172526
111	Мельникова Валентина Ивановна	Melnikova Valentina Ivanovna	approved	\N	\N	\N	1	2026-05-29 11:00:46.380229	2026-05-29 11:00:46.380229	2026-05-29 11:00:46.380229
112	Павлов Виктор Михайлович	Pavlov Viktor Mikhailovich	approved	\N	\N	\N	1	2026-05-29 11:00:46.475132	2026-05-29 11:00:46.475132	2026-05-29 11:00:46.475132
113	Рыжикова Мария Игоревна	Ryzhikova Maria Igorevna	approved	\N	\N	\N	1	2026-05-29 11:00:46.574942	2026-05-29 11:00:46.574942	2026-05-29 11:00:46.574942
114	Сафонов Дмитрий Александрович	Safonov Dmitry Alexandrovich	approved	\N	\N	\N	1	2026-05-29 11:00:46.68034	2026-05-29 11:00:46.68034	2026-05-29 11:00:46.68034
115	Селиванова Елена Аркадьевна	Selivanova Elena Arkadyevna	approved	\N	\N	\N	1	2026-05-29 11:00:46.777421	2026-05-29 11:00:46.777421	2026-05-29 11:00:46.777421
116	Дягилев Руслан Андреевич	Dyagilev Ruslan Andreevich	approved	\N	\N	\N	1	2026-05-29 11:00:46.878747	2026-05-29 11:00:46.878747	2026-05-29 11:00:46.878747
110	Абубакиров Искандер Радиевич	Abubakirov Iskander Radievich	approved	\N	\N	\N	1	2026-05-29 12:17:31.053237	2026-05-29 11:00:46.275571	2026-05-29 12:17:31.053237
68	Ященко Марина Георгиевна	Yashchenko Marina Georgievna	approved	\N	\N	\N	4	2026-06-05 12:13:23.293117	2026-05-29 11:00:41.588116	2026-06-05 12:13:23.293117
\.


--
-- Data for Name: repositoryorganizations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repositoryorganizations (id, name_ru, name_en, status, requested_by_user_id, requester_name, requester_email, approved_by, approved_at, created_at, updated_at, full_name_ru, full_name_en) FROM stdin;
9	ИГ ФИЦ Коми НЦ УрО РАН	IG Komi SC UB RAS	approved	1	\N	\N	1	2026-05-28 10:02:11.73758	2026-05-28 10:02:11.645111	2026-05-28 10:02:11.73758	Институт геологии им. академика Н.П. Юшкина Коми научного центра Уральского отделения Российской академии наук	Institute of Geology named after academician N.P. Yushkin, Komi Science Centre of the Ural Branch of the Russian Academy of Sciences
2	ИДГ РАН	IDG RAS	approved	7	Сдельникова Ирина Александровна	newsbox@gsras.ru	4	2026-05-29 10:46:10.564064	2026-05-19 14:55:28.224219	2026-05-29 10:46:10.564064	Федеральное государственное бюджетное учреждение науки Институт динамики геосфер имени академика М.А. Садовского Российской академии наук	Institute of Geosphere Dynamics of the Russian Academy of Sciences
6	БФ ФИЦ ЕГС РАН	BB GS RAS	approved	1	\N	\N	1	2026-05-28 10:02:10.818922	2026-05-28 10:02:10.718715	2026-05-28 10:02:10.818922	Байкальский филиал Федерального государственного бюджетного учреждения науки Федерального исследовательского центра "Единая геофизическая служба Российской академии наук"	Baikal Branch of the Geophysical Survey of the Russian Academy of Sciences
7	ГИ УрО РАН	MI UB RAS	approved	1	\N	\N	1	2026-05-28 10:02:11.131951	2026-05-28 10:02:11.036629	2026-05-28 10:02:11.131951	Горный институт Уральского отделения Российской академии наук - филиал Федерального государственного бюджетного учреждения науки Пермского федерального исследовательского центра Уральского отделения Российской академии наук	Mining Institute of the Ural Branch of the Russian Academy of Sciences
10	ИСГ КФУ	ISG CFU	approved	1	\N	\N	1	2026-05-28 10:02:12.03767	2026-05-28 10:02:11.94395	2026-05-28 10:02:12.03767	Институт сейсмологии и геодинамики федерального государственного автономного образовательного учреждения высшего образования "Крымский федеральный университет имени В.И. Вернадского"	Institute of seismology and geodynamics of the Federal State Autonomous Educational Institution of Higher Education "V.I. Vernadsky Crimean Federal University"
8	ДФ ФИЦ ЕГС РАН	DF GS RAS	approved	1	\N	\N	1	2026-05-28 10:02:11.433087	2026-05-28 10:02:11.337242	2026-05-28 10:02:11.433087	Дагестанский филиал Федерального государственного бюджетного учреждения науки Федерального исследовательского центра "Единая геофизическая служба Российской академии наук"	Dagestan Branch of the Geophysical Survey of the Russian Academy of Sciences
11	ИФЗ РАН	IPE RAS	approved	1	\N	\N	1	2026-05-28 10:02:12.366601	2026-05-28 10:02:12.26988	2026-05-28 10:02:12.366601	Федеральное государственное бюджетное учреждение науки Институт физики Земли им. О.Ю. Шмидта Российской академии наук	Schmidt Institute of Physics of the Earth of the Russian Academy of Sciences
13	КФ ФИЦ ЕГС РАН	KB GS RAS	approved	1	\N	\N	4	2026-06-05 10:48:38.03455	2026-05-28 10:02:12.877681	2026-06-05 10:48:38.03455	Камчатский филиал Федерального государственного бюджетного учреждения науки Федерального исследовательского центра "Единая геофизическая служба Российской академии наук"	Kamchatka Branch of the Geophysical Survey of the Russian Academy of Sciences
14	МФ ФИЦ ЕГС РАН	MB GS RAS	approved	1	\N	\N	1	2026-05-28 10:02:13.283425	2026-05-28 10:02:13.186927	2026-05-28 10:02:13.283425	Магаданский филиал Федерального государственного бюджетного учреждения науки Федерального исследовательского центра "Единая геофизическая служба Российской академии наук"	Magadan branch of the Geophysical survey of the Russian academy of sciences
15	СОФ ФИЦ ЕГС РАН	NOB GS RAS	approved	1	\N	\N	1	2026-05-28 10:02:13.603537	2026-05-28 10:02:13.507844	2026-05-28 10:02:13.603537	Северо-Осетинский филиал Федерального государственного бюджетного учреждения науки Федерального исследовательского центра "Единая геофизическая служба Российской академии наук"	North Ossetian Branch of the Geophysical Survey of the Russian Academy of Sciences
16	СФ ФИЦ ЕГС РАН	SB GS RAS	approved	1	\N	\N	1	2026-05-28 10:02:13.908542	2026-05-28 10:02:13.813438	2026-05-28 10:02:13.908542	Сахалинский филиал Федерального государственного бюджетного учреждения науки Федеральный исследовательский центр "Единая геофизическая служба Российской академии наук"	Sakhalin Branch of the Geophysical survey of the Russian academy of sciences
5	АСФ ФИЦ ЕГС РАН	ASB GS RAS	approved	1	\N	\N	4	2026-05-29 10:45:33.613521	2026-05-28 10:02:10.395513	2026-05-29 10:45:33.613521	Алтае-Саянский филиал Федерального государственного бюджетного учреждения науки Федерального исследовательского центра "Единая геофизическая служба Российской академии наук"	Altai-Sayan Branch of the Geophysical Survey of the Russian Academy of Sciences
1	ФИЦ ЕГС РАН	GS RAS	approved	7	Сдельникова Ирина Александровна	newsbox@gsras.ru	1	2026-05-13 12:30:18.656383	2026-04-30 09:53:36.274745	2026-06-29 17:12:29.723388	Федеральное государственное бюджетное учреждение науки Федеральный исследовательский центр "Единая геофизическая служба Российской академии наук"	Geophysical survey of the Russian academy of sciences
12	КоФ ФИЦ ЕГС РАН	Kola Branch GS RAS	approved	1	\N	\N	4	2026-06-05 10:48:19.602985	2026-05-28 10:02:12.573151	2026-06-05 10:48:19.602985	Кольский филиал Федерального государственного бюджетного учреждения науки Федеральный исследовательский центр "Единая геофизическая служба Российской академии наук"	Kola branch of the Geophysical Survey of the Russian Academy of Sciences
17	ФГБУН ФИЦКИА УрО РАН	FECIAR UrB RAS	approved	1	\N	\N	1	2026-05-28 10:02:14.214976	2026-05-28 10:02:14.120741	2026-05-28 10:02:14.214976	Федеральное государственное бюджетное учреждение науки Федеральный исследовательский центр комплексного изучения Арктики имени академика Н.П. Лаверова Уральского отделения Российской академии наук	N. Laverov Federal Center for Integrated Arctic Research of the Ural Branch of the Russian Academy of Sciences
18	ЯФ ФИЦ ЕГС РАН	YB GS RAS	approved	1	\N	\N	1	2026-05-28 10:02:14.553521	2026-05-28 10:02:14.457303	2026-05-28 10:02:14.553521	Якутский филиал Федерального государственного бюджетного учреждения науки Федерального исследовательского центра "Единая геофизическая служба Российской академии наук"	Yakut Branch of the Geophysical Survey of the Russian Academy of Sciences
\.


--
-- Data for Name: repositorypasswordresettokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repositorypasswordresettokens (id, repository_user_id, token, expires_at, used, created_at) FROM stdin;
1	1	222868b2891e0bbee8cc915d69616ecf04330b7bb2384c25b2a4df8a5fc7b280	2026-04-08 13:48:49.222	t	2026-04-08 12:48:49.223386
\.


--
-- Data for Name: repositoryuserprofileupdaterequests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repositoryuserprofileupdaterequests (id, repository_user_id, requested_changes, status, admin_comment, reviewed_by, reviewed_at, created_at, updated_at) FROM stdin;
1	7	{"position": "старший научный сотрудник"}	approved	\N	4	2026-06-18 12:02:02.172817	2026-06-18 12:00:36.913624	2026-06-18 12:02:02.172817
\.


--
-- Data for Name: repositoryusers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repositoryusers (id, name, full_name, email, organization, "position", password, password_changed_at, role, status, created_at, updated_at, approved_by, approved_at, organization_id, personal_data_consent, personal_data_consent_at) FROM stdin;
11	editor	Склемин Олег Сергеевич	skleminos@gsras.ru	ФИЦ ЕГС РАН	Инженер-программист	$2a$12$P9K7VMTM7z3Fe9adqRvYGue6IqXR44Me.cMgRPgwkU57yUZTDbKom	\N	user	active	2026-06-04 11:03:51.164366	2026-06-04 11:04:02.916131	1	2026-06-04 11:04:02.916131	1	f	\N
12	arinahotinskaya	Хотинская Арина Николаевна	arinakhotinskaya@mail.ru	ФИЦ ЕГС РАН	Младший научный сотрудник	$2a$12$f.AdOMIXbRDYLB4BZ0BCiOR.AnGj8olO7v.eIyFwF18vISXfp57tu	\N	user	active	2026-06-04 15:21:53.279137	2026-06-04 15:29:21.008833	4	2026-06-04 15:29:21.008833	1	f	\N
13	Marina_2880	Ефременко Марина Алексеевна	2880@mail.ru	ФИЦ ЕГС РАН	нс	$2a$12$D608Fb7LrkvSzRVdGV92peWZFUfXpFN7n.R3F40hDrZYKep5VNXz2	\N	user	active	2026-06-04 16:12:03.962628	2026-06-04 16:12:39.285979	4	2026-06-04 16:12:39.285979	1	f	\N
1	skleminos	Склемин Олег Сергеевич	skleminos21@oiate.ru	ФИЦ ЕГС РАН	Инженер-програмист 2 категории	$2a$12$4bceKsJznZxss5VOI4hvr.hPZp1.c58Z8/JJzjLBfTRi6fqtUOOzO	2026-04-08 12:50:54.362619	admin	active	2026-04-07 10:44:46.86111	2026-05-14 12:29:05.552815	\N	\N	1	f	\N
4	sdelnikova	Сдельникова Ирина Александровна	sdelnikova@gsras.ru	ФИЦ ЕГС РАН	ученый секретарь	$2a$12$nwQqmipX/dHBWL7ovSBvbukjRvE9DsZHEMThYloyBMPTVzlpNpZ4G	\N	admin	active	2026-04-20 10:40:23.933872	2026-05-14 12:29:05.552815	1	2026-04-20 10:47:17.546624	1	f	\N
5	us	Сдельникова Ирина Александровна	us@gsras.ru	ФИЦ ЕГС РАН	ученый секретарь	$2a$12$GiV9Hf555awraKRYr5.EMe/n8zL3fFgMMtXNHBcVlLIGEVWns3k3K	\N	editor	active	2026-04-23 11:18:26.269346	2026-05-14 12:29:05.552815	4	2026-04-23 11:18:59.155602	1	f	\N
15	Anna	Курова Анна Дмитриевна	anya-moro1112@yandex.ru	ФИЦ ЕГС РАН	Младший научный сотрудник	$2a$12$6.hxFbSsuCu8myWptSb6e.GLwdMchg7vhuTuzC4XjVPNylllTPRva	\N	user	active	2026-06-06 11:20:36.159727	2026-06-08 09:28:26.10773	4	2026-06-08 09:28:26.10773	1	f	\N
7	irina_guest	Сдельникова Ирина Александровна	newsbox@gsras.ru	ФИЦ ЕГС РАН	старший научный сотрудник	$2a$12$QiJFrXGLlS8B48T4av6Tlu00icUXdJuno/wNtaIO8EBj5761yX9/W	\N	user	active	2026-04-28 11:07:59.955752	2026-06-18 12:02:02.172817	4	2026-05-05 18:08:24.19061	1	f	\N
\.


--
-- Name: repositoryauthororganizations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.repositoryauthororganizations_id_seq', 124, true);


--
-- Name: repositoryauthors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.repositoryauthors_id_seq', 116, true);


--
-- Name: repositoryorganizations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.repositoryorganizations_id_seq', 20, true);


--
-- Name: repositorypasswordresettokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.repositorypasswordresettokens_id_seq', 1, true);


--
-- Name: repositoryuserprofileupdaterequests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.repositoryuserprofileupdaterequests_id_seq', 1, true);


--
-- Name: repositoryusers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.repositoryusers_id_seq', 15, true);


--
-- Name: repositoryauthororganizations repository_author_organizations_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositoryauthororganizations
    ADD CONSTRAINT repository_author_organizations_unique UNIQUE (author_id, organization_id);


--
-- Name: repository_personal_drafts repository_personal_drafts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repository_personal_drafts
    ADD CONSTRAINT repository_personal_drafts_pkey PRIMARY KEY (document_id);


--
-- Name: repositoryauthororganizations repositoryauthororganizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositoryauthororganizations
    ADD CONSTRAINT repositoryauthororganizations_pkey PRIMARY KEY (id);


--
-- Name: repositoryauthors repositoryauthors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositoryauthors
    ADD CONSTRAINT repositoryauthors_pkey PRIMARY KEY (id);


--
-- Name: repositoryorganizations repositoryorganizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositoryorganizations
    ADD CONSTRAINT repositoryorganizations_pkey PRIMARY KEY (id);


--
-- Name: repositorypasswordresettokens repositorypasswordresettokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositorypasswordresettokens
    ADD CONSTRAINT repositorypasswordresettokens_pkey PRIMARY KEY (id);


--
-- Name: repositorypasswordresettokens repositorypasswordresettokens_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositorypasswordresettokens
    ADD CONSTRAINT repositorypasswordresettokens_token_key UNIQUE (token);


--
-- Name: repositoryuserprofileupdaterequests repositoryuserprofileupdaterequests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositoryuserprofileupdaterequests
    ADD CONSTRAINT repositoryuserprofileupdaterequests_pkey PRIMARY KEY (id);


--
-- Name: repositoryusers repositoryusers_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositoryusers
    ADD CONSTRAINT repositoryusers_email_key UNIQUE (email);


--
-- Name: repositoryusers repositoryusers_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositoryusers
    ADD CONSTRAINT repositoryusers_name_key UNIQUE (name);


--
-- Name: repositoryusers repositoryusers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositoryusers
    ADD CONSTRAINT repositoryusers_pkey PRIMARY KEY (id);


--
-- Name: repository_author_organizations_author_organization_unique_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX repository_author_organizations_author_organization_unique_idx ON public.repositoryauthororganizations USING btree (author_id, organization_id);


--
-- Name: repository_authors_name_pair_unique_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX repository_authors_name_pair_unique_idx ON public.repositoryauthors USING btree (lower((name_ru)::text), lower((name_en)::text));


--
-- Name: repository_organizations_name_en_unique_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX repository_organizations_name_en_unique_idx ON public.repositoryorganizations USING btree (lower((name_en)::text)) WHERE ((name_en IS NOT NULL) AND ((name_en)::text <> ''::text));


--
-- Name: repository_organizations_name_ru_unique_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX repository_organizations_name_ru_unique_idx ON public.repositoryorganizations USING btree (lower((name_ru)::text));


--
-- Name: repository_password_reset_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repository_password_reset_user_idx ON public.repositorypasswordresettokens USING btree (repository_user_id, expires_at);


--
-- Name: repository_personal_drafts_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repository_personal_drafts_status_idx ON public.repository_personal_drafts USING btree (document_status, updated_at DESC);


--
-- Name: repository_personal_drafts_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repository_personal_drafts_user_idx ON public.repository_personal_drafts USING btree (user_id, updated_at DESC);


--
-- Name: repository_user_profile_update_requests_pending_user_unique_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX repository_user_profile_update_requests_pending_user_unique_idx ON public.repositoryuserprofileupdaterequests USING btree (repository_user_id) WHERE ((status)::text = 'pending'::text);


--
-- Name: repository_user_profile_update_requests_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repository_user_profile_update_requests_status_idx ON public.repositoryuserprofileupdaterequests USING btree (status, created_at DESC);


--
-- Name: repository_user_profile_update_requests_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repository_user_profile_update_requests_user_idx ON public.repositoryuserprofileupdaterequests USING btree (repository_user_id, created_at DESC);


--
-- Name: repository_users_organization_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repository_users_organization_id_idx ON public.repositoryusers USING btree (organization_id);


--
-- Name: repositoryusers repository_users_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositoryusers
    ADD CONSTRAINT repository_users_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.repositoryorganizations(id) ON DELETE SET NULL;


--
-- Name: repositoryauthororganizations repositoryauthororganizations_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositoryauthororganizations
    ADD CONSTRAINT repositoryauthororganizations_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.repositoryusers(id) ON DELETE SET NULL;


--
-- Name: repositoryauthororganizations repositoryauthororganizations_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositoryauthororganizations
    ADD CONSTRAINT repositoryauthororganizations_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.repositoryauthors(id) ON DELETE CASCADE;


--
-- Name: repositoryauthororganizations repositoryauthororganizations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositoryauthororganizations
    ADD CONSTRAINT repositoryauthororganizations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.repositoryorganizations(id) ON DELETE CASCADE;


--
-- Name: repositoryauthororganizations repositoryauthororganizations_requested_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositoryauthororganizations
    ADD CONSTRAINT repositoryauthororganizations_requested_by_user_id_fkey FOREIGN KEY (requested_by_user_id) REFERENCES public.repositoryusers(id) ON DELETE SET NULL;


--
-- Name: repositoryauthors repositoryauthors_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositoryauthors
    ADD CONSTRAINT repositoryauthors_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.repositoryusers(id) ON DELETE SET NULL;


--
-- Name: repositoryauthors repositoryauthors_requested_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositoryauthors
    ADD CONSTRAINT repositoryauthors_requested_by_user_id_fkey FOREIGN KEY (requested_by_user_id) REFERENCES public.repositoryusers(id) ON DELETE SET NULL;


--
-- Name: repositoryorganizations repositoryorganizations_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositoryorganizations
    ADD CONSTRAINT repositoryorganizations_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.repositoryusers(id) ON DELETE SET NULL;


--
-- Name: repositoryorganizations repositoryorganizations_requested_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositoryorganizations
    ADD CONSTRAINT repositoryorganizations_requested_by_user_id_fkey FOREIGN KEY (requested_by_user_id) REFERENCES public.repositoryusers(id) ON DELETE SET NULL;


--
-- Name: repositorypasswordresettokens repositorypasswordresettokens_repository_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositorypasswordresettokens
    ADD CONSTRAINT repositorypasswordresettokens_repository_user_id_fkey FOREIGN KEY (repository_user_id) REFERENCES public.repositoryusers(id) ON DELETE CASCADE;


--
-- Name: repositoryuserprofileupdaterequests repositoryuserprofileupdaterequests_repository_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositoryuserprofileupdaterequests
    ADD CONSTRAINT repositoryuserprofileupdaterequests_repository_user_id_fkey FOREIGN KEY (repository_user_id) REFERENCES public.repositoryusers(id) ON DELETE CASCADE;


--
-- Name: repositoryuserprofileupdaterequests repositoryuserprofileupdaterequests_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositoryuserprofileupdaterequests
    ADD CONSTRAINT repositoryuserprofileupdaterequests_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.repositoryusers(id) ON DELETE SET NULL;


--
-- Name: repositoryusers repositoryusers_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositoryusers
    ADD CONSTRAINT repositoryusers_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.repositoryusers(id);


--
-- PostgreSQL database dump complete
--

\unrestrict B9VVQ8BuvyBMBMvDWiWCnA96r2RJflZMIFDsx7ThoScnHa6OtXIkSkFhSvdoIlw

